/*Franky Zhang Armor Class
**This class implements the armor class which is extended from artifact class.
**It makes a character be able to equip and dequip armor which raises defense stat.
*/
//package hw1cs342;
import java.util.*;

public class Armor extends Artifact{
  //constructor
  public Armor(Scanner s){
    super(s);
  }
  /* Player can call to equip armor which will equip armor
   * based on name, then it will increase defense stat by a set amount
   * this also removes the armor artifact from inventory
   * if there is already an equipped armor, return error
   * Change equip to true if character equips an armor set, print confirmation
   */
  public void EquipArmor(Character c, Artifact s){
    if(c.getEquipArmor()){
      System.out.println("Can't equip anymore armor, please dequip current one.");
    }
    else if(s.name().equalsIgnoreCase("Cloth Armor")){
      c.changeDefense(20);
      c.removeArtifactByName(s.name());
      c.setEquipArmor(true);
      System.out.println("Equipped Cloth Armor");
    }
    else if(s.name().equalsIgnoreCase("Leather Armor")){
      c.changeDefense(20);
      c.removeArtifactByName(s.name());
      c.setEquipArmor(true);
      System.out.println("Equipped Leather Armor");
    }
    else if(s.name().equalsIgnoreCase("Heavy Armor")){
      c.changeDefense(20);
      c.removeArtifactByName(s.name());
      c.setEquipArmor(true);
      System.out.println("Equipped Heavy Armor");
    }
  }
  /*Player can call to dequip an armor set which will remove armor equipped
   * from character and place it in inventory, which will
   * decrease character defense stat by a set amount
   * if there is no armor equipped, return error
   * if successful, change equipArmor bool to false and print confirmation
   */
  public void DequipArmor(Character c, Artifact s){
    if(!c.getEquipArmor()){
      System.out.println("Can't dequip any armor, please equip one.");
    }
    else if(s.name().equalsIgnoreCase("Cloth Armor")){
      c.changeDefense(-20);
      c.addArtifact(s);
      c.setEquipArmor(false);
      System.out.println("Dequipped Cloth Armor");
    }
    else if(s.name().equalsIgnoreCase("Leather Armor")){
      c.changeDefense(-30);
      c.addArtifact(s);
      c.setEquipArmor(false);
      System.out.println("Dequipped Leather Armor");
    }
    else if(s.name().equalsIgnoreCase("Heavy Armor")){
      c.changeDefense(-40);
      c.addArtifact(s);
      c.setEquipArmor(false);
      System.out.println("Dequipped Heavy Armor");
    }
  }
}
