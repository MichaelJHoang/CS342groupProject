/* Franky Zhang
** This class extends from the artifact class and declares a potion, it has one main overriding
** function in that a player character can use it to heal or gain stats. Only player for now.  
*/
//package hw1cs342;
import java.util.*;


public class Consumables extends Artifact{
	//constructor
  public Consumables(Scanner s){
    super(s);
  }
  
  // JON-MICHAEL HOANG WAS HERE JON-MICHAEL HOANG WAS HERE JON-MICHAEL HOANG WAS HERE
  // constructor to allow the creation of items mid-game
  public Consumables(String name)
  {
	  super(name);
  }
  
  /*if user is a player, it can use any consumable
   * The stat increased depends on consumable name
   * if not player, will produce error
   */
  public void use(Character c, Artifact s){
    if(c instanceof Player){
      if(s.name().equalsIgnoreCase("Small HP Pot")){
      	c.heal(20);
     	c.removeArtifactByName(s.name());
      }
      else if(s.name().equalsIgnoreCase("Medium HP Pot")){
        c.heal(40);
        c.removeArtifactByName(s.name());
      }
      else if(s.name().equalsIgnoreCase("Large HP Pot")){
	    c.heal(60);
	    c.removeArtifactByName(s.name());
      }
      else if(s.name().equalsIgnoreCase("DefPot")){
        c.changeDefense(20);
        c.removeArtifactByName(s.name());
      }
      else if(s.name().equalsIgnoreCase("AtkPot")){
        c.changeAttack(20);
        c.removeArtifactByName(s.name());
      }
      else if(s.name().equalsIgnoreCase("LuckPot")){
        c.changeLuck(10);
        c.removeArtifactByName(s.name());
      }
      // JON-MICHAEL HOANG WAS HERE JON-MICHAEL HOANG WAS HERE JON-MICHAEL HOANG WAS HERE JON-MICHAEL HOANG WAS HERE
      // the three items below are only obtainable from event places
      else if (s.name.equalsIgnoreCase("???"))
      {
    	  System.out.println("\nYou used the mysterious item..." +
    			  			 "\nYou feel...strange");
    	  
    	  Random rand = new Random ();
    	  
    	  c.debuff(rand.nextInt(5));
    	  c.buff(rand.nextInt(5));
      }
      else if (s.name.equalsIgnoreCase("Magic Mushrooms"))
      {
    	  System.out.println("\nYou take a bite of the mushroom");
    	  c.takeDamage(999999999);
    	  System.out.println("You died - you should've known not to eat mushrooms of mysterious origins...");
      }
      // Easter egg item that pretty much force exits.
      else if (s.name.equalsIgnoreCase("THE FORBIDDEN ITEM"))
      {
    	  System.out.println("You used [ THE FORBIDDEN ITEM ] out of sheer curiosity..." +
    			  			 "\nThe world instantly turns dark - it is gone.");
    	  System.exit(666);
      }
    }
    else{
      System.out.println("You are not a Player Character, FORBIDDEN TO USE");
    }
  } 
}
