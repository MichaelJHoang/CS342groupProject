Group: 51
Members:
	Dilip Vemuri - dvemuri3
	Jon-Michael Hoang - jhoang6
	Franky Zhang - xzhan40
	
Homework 4

General Info: 
	The program runs on gdf file format 5.1 , we included a test file in our 
	submission. The documentation of the file is properly kept in the included
	GDF File Format word document. The program will run with the test file. The
	Program IS NOT BACKWARDS COMPATIBLE. At startup, the program can take up to
	two command line arguments. Argument 1 is the filename, argument 2 is the
	number of players you want. Anymore than 2 the player exits. 0 commandline
	arguments asks the user for a file name.
	
	When the game runs, you will have a chance to control every player character for
	a turn. A list of commands is given by typing CMD when it's a players turn. For now
	All commands must be given in CAPS lock, i.e LOOK , INVENTORY, EXIT etc. Typing exit
	will remove a singular character. Typing QUIT will exit the program. The player can attack
	other players, generic NPCs and Ogres. Cannot Attack merchants and dogs. Players can recieve
	damage and die of fatal wounds.
	
	
Dilip Vemuri:
	-In charge of combining the code at the initial stage.
	-In charge of Character, Move and DecisionMaker.
	-Was in charge of the character class, added 3 new NPC types:
		Ogre, Merchant, DOG
	-Ogre and DOG had two new DecisionMakers, OgreAwakeAI, OgreAsleepAI, EnemyDogAI
	FriendlyDogAI respectively. Merchant had one AI.
	-Character had new fields added to it, Namely Health, Attack, Gold, Defense and luck.
	-For now, only Players and Ogre can recieve damage. I intentionally left the Dog immune.	
	-DecisionMakers for each Character class encapsulated a move in the Move class.
	-The individual move types were created in every Character class. I.e. executeUse(), executeGo()
	-Merchants do not do anything without the player interacting with them. When Players use
	Trade "Merchant name" they have the option to BUY, SELL, EXIT. 
	-DOGs can be PET by the player, and petting a dog will turn it friendly and it will follow the player.
	dogs will also attack enemies of the player.
	-Generic NPCs are still available, they wander around and do nothing.
	-many more Changes to all the Character/DecisionMaker classes.

Franky Zhang:	
	-In charge of Weapon, Armor, Consumable, and Artifact classes.
	-Made different types of armor, weapon, consumables to be dropped in different places(file)
	-Made changes in Character class:
	*Setters and Getters to get information from character and changing it based on equipment
	*an Equip function for a character to be able to equip at most 1 of armor, weapon
	*characters can hold multiple potions
	*characters can use a potion which calls character.heal function
	-Updated GDF 5.1 for artifact portion
	-Changed Game file to be able to read new types of artifacts
	-Only Players can use consumables
	-Characters can use Armor and Weapon, however it might not be implemented in Move
	-Picking up weapon and armor should now increase attack and defense
	-This increases damage dealt and reduces damage taken for attacking portion of move
	-Upcoming changes: Attack speed? Accuracy? Weight Slowdown for speed(skip a move if you're too heavy?)

Jon-Michael Hoang:
	- In charge of Places, EventPlace, and Event classes
	- Created event places whose event "RNG" values are based off of two things:
		- Sum of the luck stats
		- Amount of characters within the room
	  Using those two values, I utilized a hash function based off of Daniel J.
	  Bernstein's 2nd hashing function and used it to produce a random number.
	  Using that random number, I take certain digits from it, throw it into a
	  switch case, and producing "random" events.

		- Created a LIGHT VERSION of the RNG also just in case something fails.
		  The code can be located in EventPlace.java

	  These events can help or harm a character/player.
	- Added buff, debuff, etc. functions within [ Character.java ] to allow events to access
	  a character's stats.
	- Change Game files to create event rooms through the pre-exisitng loop function to create rooms
	  and created an event room instead IFF [ i ] is ODD.

	- Modified others' files to aid in the implementation of EVENTS within [ Characters.java ], [ Artifact.java ], and
	  [ Consumables.java ], etc.
	- Added Easter Eggs.

	Considerations:
		- Prove effectiveness of the hash/RNG function
		- Implement brightness for rooms
		- Include more random events from ~10 to possibly ~25 different types?
		- Use certain digits within hash/RNG value to support it?

	- For more information in respect to my contributions, just look for related files where
	  I marked my name is there.