/*
 * 
 * Author: Jon-Michael Hoang
 * 
 * This file contains the class that extends Place to an event place
 * so that special effects can occur when someone leaves/enters a certain place.
 * 
 */

import java.util.*;

public class EventPlace extends Place
{
	// book-keeping 
	private int previousPopulation;
	private int currentPopulation;
	
    public EventPlace (Scanner file)
    {
    	super(file);
    	
    	previousPopulation = characterList.size(); // provided that there are any characters that spawn in a place
    	currentPopulation = characterList.size();
    }
    
    public EventPlace (int placeID, String name, String desc)
    {
    	super(placeID, name, desc);
    	
    	previousPopulation = characterList.size(); // provided that there are any characters that spawn in a place
    	currentPopulation = characterList.size();
    }
    
    // display message if an event was triggered
    private void notifyEventTrigger ()
    {
    	System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
    	System.out.println("A door was opened and an event was triggered.");
    	System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
    }
    
    protected void triggerEvent(int eventRNG)
	{
    	System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
    	if (eventRNG == 0)
    	{
    		// I'm a lazy programmer and I don't wanna divide by zero.
    		System.out.println("\n...?\nNothing happened...");
    		System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
    		return;
    	}
    	// Super rare Easter Egg
    	else if (eventRNG == 666)
    	{
    		System.out.println("True evil rings in the air...it has arrived.");
    		for (Character iter : characterList)
    			iter.addArtifact(new Consumables("THE FORBIDDEN ITEM"));
    		
    		System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
    		return;
    	}
    	
    	System.out.print("\n");
    	
    	// take the most significant digit
    	eventRNG = String.valueOf(Math.abs((long)eventRNG)).charAt(0) - '0';
    	
    	Random rand = new Random();
    	
    	// TODO: FIND UNIQUE EVENTS FOR CASES [ 6 ] AND [ 4 ]
    	switch (eventRNG)
    	{
    		// buff the character
    		case 9:
    			System.out.println("You feel...refreshed.");
    			for (Character iter : characterList)
    			{
    				if (iter instanceof Player)
    				{
    					iter.refresh(5);
    					// add a little suprise
    					iter.addArtifact(new Consumables("Medium HP Pot"));
    				}
    			}
    			break;
    		
    		// give all the players a special consumable
    		// CONSIDERATION: +Weapon/Armor?
    		case 8:
    			System.out.println("Every player has been given a special item!");
    			for (Character iter : characterList)
    			{
    				if (iter instanceof Player)
    				{
    					switch (rand.nextInt(6))
    					{
    						case 0:
    							iter.addArtifact(new Consumables ("Small HP Pot"));
    							break;
    						case 1:
    							iter.addArtifact(new Consumables ("Medium HP Pot"));
    							break;
    						case 2:
    							iter.addArtifact(new Consumables ("Large HP Pot"));
    							break;
    						case 3:
    							iter.addArtifact(new Consumables ("DefPot"));
    							break;
    						case 4:
    							iter.addArtifact(new Consumables ("AtkPot"));
    							break;
    						case 5:
    							iter.addArtifact(new Consumables ("LuckPot"));
    							break;
    						// hoping it never reaches the default case...
    						default:
    							iter.addArtifact(new Consumables ("Magic Mushrooms"));
    							break;
    					}
    				}
    			}
    			break;

    		// 777 luck 777
    		case 7:
    			// because 7 => 777 => luck
    			System.out.println("Luck rings in the air");
    			
    			for (Character iter : characterList)
    				if (iter instanceof Player)
    					if (rand.nextInt(iter.luck()) >= (iter.luck() * .75))
    					{
    						iter.changeLuck(5);
    						iter.changeGold(rand.nextInt(100));
    					}
    			
    			break;
    		// Spawn in mysterious items into the character's inventory for cases 6 -> 4
    		// CONSIDERATION: Something else that is unique for cases [ 6 ] and [ 4 ]?
    		case 6:
    			System.out.println("...?" + "\nDid something happen? Didn't seem like it...");
    			
    			for (Character iter : characterList)
    			{
    				iter.addArtifact(new Consumables ("???"));
    				
    				if (iter.luck() % 7 == 0)
    					iter.addArtifact(new Consumables ("Magic Mushrooms"));
    			}
    			break;
    			
    		case 5:
    			System.out.println("...?" + "\nDid something happen? Didn't seem like it...");
    			
    			for (Character iter : characterList)
    			{
    				iter.addArtifact(new Consumables ("???"));
    				
    				if (iter.luck() % 7 == 0)
    					iter.addArtifact(new Consumables ("Magic Mushrooms"));
    			}
    			break;
    			
    		case 4:
    			System.out.println("...?" + "\nDid something happen? Didn't seem like it...");
    			
    			for (Character iter : characterList)
    			{
    				iter.addArtifact(new Consumables ("???"));
    				
    				if (iter.luck() % 7 == 0)
    					iter.addArtifact(new Consumables ("Magic Mushrooms"));
    			}
    			break;
    		
    		// boom.
    		case 3:
    			System.out.println("An explosion went off - damaging those near it!");
    			for (Character iter : characterList)
    				iter.takeDamage((iter.health() > 20) ? iter.health() - 20 : iter.health() - 1);
    			break;
    		
    		// debuff and "mysteriously drop" everyone's items without them noticing it
    		case 2:
    			System.out.println("An unknown force knocks everyone out.");
    			for (Character iter : characterList)
    			{
    				iter.debuff(rand.nextInt(5));
    				
    				while (iter.inventory.size() != 0)
    				{
    					artifactList.add(iter.removeArtifact_event());
    				}
    			}
    			System.out.println("Fatigue roams about the air...");
    			break;
    		
    		// this means game over for someone...
    		case 1:
    			System.out.println("The room suddenly becomes dark...");
    			
    				// KILL A RANDOM CHARACTER - IT DOESN'T MATTER WHO
	    			characterList.get(rand.nextInt(characterList.size() - 1)).takeDamage(999999999);
	    			
    			System.out.println("...and instantly becomes bright again.");
    			System.out.println("\nHowever, there is now a pool of blood on the ground...");
    			System.out.println("To whom did it belong?");
    			break;
    			
    		default:
    			System.out.println("...?\nNothing happened...");
    			break;
    		
    	}
    	
    	System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
    	
    	return;
	}
    
    public void getEvent ()
    {
    	// instantiate a new event everytime
    	Event event = (currentPopulation == previousPopulation) ? new Event (characterList) : null;
    	
    	if (event != null)
    	{
    		this.notifyEventTrigger();
    		this.triggerEvent(event.getRNG());
    		// FOR THE LIGHT VERSION, PLEASE UNCOMMENT THE LINE BELOW AND COMMENT THE LINE ABOVE
    		// this.triggerEvent(event.getRNG_light());
    		currentPopulation = previousPopulation;
    	}
    }
}