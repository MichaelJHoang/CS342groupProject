/*Franky Zhang Weapon Class
**This class implements the weapon class which is extended from artifact class.
**It makes a character be able to equip and dequip weapons which raises the attack stat.
*/
//package hw1cs342;
import java.util.*;

public class Weapon extends Artifact{  
  //constructor
  public Weapon(Scanner s){
    super(s);
  }
  /* Player can call to equip weapon which will equip weapon
   * based on name, then it will increase attack by a set amount
   * this also removes the weapon artifact from inventory
   * if there is already an equipped weapon, return error
   * Change equip to true if character equips a weapon, print confirmation
   */
  public void EquipWeapon(Character c, Artifact s){
    if(c.getEquipWeapon()){
      System.out.println("Can't equip another weapon, please dequip current one.");
    }
    else if(s.name().equalsIgnoreCase("Short Sword")){
      c.changeAttack(10);
      //c.attackSpeed = 4? (4 hits a move?)
      //c.accuracy = 0.75? (75% of hitting every swing?)
      c.removeArtifactByName(s.name());
      c.setEquipWeapon(true);
      System.out.println("Equipped Sword Sword");
    }
    else if(s.name().equalsIgnoreCase("Long Sword")){
      c.changeAttack(30);
      //c.attackSpeed = 1? (1 hit a move?)
      //c.accuracy = 1? (100% of hitting every swing?)
      c.removeArtifactByName(s.name());
      c.setEquipWeapon(true);
      System.out.println("Equipped Long Sword");
    }
    else if(s.name().equalsIgnoreCase("Axe")){
      c.changeAttack(75);
      //c.attackSpeed = 1? (1 hit a move?)
      //c.accuracy = 0.5? (50% of hitting?)
      c.removeArtifactByName(s.name());
      c.setEquipWeapon(true);
      System.out.println("Equipped Axe");
    }
    //found in treasure storeroom?
    else if(s.name().equalsIgnoreCase("Legendary Ogre Slayer")){
      c.changeAttack(100);
      //c.attackSpeed = 1?
      //c.accuracy = 1?
      c.removeArtifactByName(s.name());
      c.setEquipWeapon(true);
      System.out.println("Equipped Legendary Ogre Slayer, NOW YOU OP!!!!!!!");
    }
  }
  /*Player can call to dequip a weapon which will take a weapon equipped
   * from character and place it in inventory, which will
   * decrease character attack stat by a set amount
   * if there is no weapon equipped, return error
   * if successful, change equipWeapon bool to false and print confirmation
   */
  public void DequipWeapon(Character c, Artifact s){
    if(!c.getEquipWeapon()){
      System.out.println("Can't dequip a weapon, You have none!");
    }
    else if(s.name().equalsIgnoreCase("Short Sword")){
      c.changeAttack(-10);
      //c.attackSpeed = 1
      //c.accuracy = 1
      c.addArtifact(s);
      c.setEquipWeapon(false);
      System.out.println("Dequipped Sword Sword");
    }
    else if(s.name().equalsIgnoreCase("Long Sword")){
      c.changeAttack(-30);
      //c.attackSpeed = 1
      //c.accuracy = 1
      c.addArtifact(s);
      c.setEquipWeapon(false);
      System.out.println("Dequipped Long Sword");
    }
    else if(s.name().equalsIgnoreCase("Axe")){
      c.changeAttack(-75);
      //c.attackSpeed = 1
      //c.accuracy = 1
      c.addArtifact(s);
      c.setEquipWeapon(false);
      System.out.println("Dequipped Axe");
    }
    else if(s.name().equalsIgnoreCase("Legendary Ogre Slayer")){
      c.changeAttack(-100);
      //c.attackSpeed = 1?
      //c.accuracy = 1?
      c.addArtifact(s);
      c.setEquipWeapon(false);
      System.out.println("Dequipped Legendary Ogre Slayer, WHYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY?!");
    }
  }

}
